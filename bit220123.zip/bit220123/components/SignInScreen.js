// SignInScreen.js
import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet } from 'react-native';

const SignInScreen = ({ navigation }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [error, setError] = useState('');

  const handleCheckPress = () => {
    if (phoneNumber.length !== 10) {
      setError('Số điện thoại phải có đúng 10 chữ số.');
    } else if (!/^\d+$/.test(phoneNumber)) {
      setError('Số điện thoại chỉ chứa các chữ số.');
    } else {
      setError('');
      // Navigate to HomeScreen when the phone number is valid
      navigation.navigate('Home');
    }
  };

  return (
    <View style={styles.container}>
      <TextInput
        style={styles.input}
        placeholder="Nhập số điện thoại"
        keyboardType="numeric"
        value={phoneNumber}
        onChangeText={(text) => setPhoneNumber(text)}
        maxLength={10} // Giới hạn số ký tự nhập vào
      />
      {error ? <Text style={styles.errorText}>{error}</Text> : null}
      <TouchableOpacity style={styles.button} onPress={handleCheckPress}>
        <Text style={styles.buttonText}>Check</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  input: {
    height: 40,
    borderColor: '#DDDDDD',
    borderWidth: 1,
    paddingLeft: 8,
    marginBottom: 12,
    width: '100%',
    borderRadius: 5,
  },
  button: {
    backgroundColor: '#6495ED',
    padding: 10,
    alignItems: 'center',
    borderRadius: 5,
    width: '100%',
  },
  buttonText: {
    color: 'white',
    fontSize: 16,
  },
  errorText: {
    color: 'red',
    marginBottom: 12,
  },
});

export default SignInScreen;
